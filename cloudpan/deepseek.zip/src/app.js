require('bytenode')
require('dotenv').config()
const express = require('express');
const app = express();
const chalk = require('chalk');
const os = require('os');
const path = require('path');

const PORT = process.env.API_PORT || 8080

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // 允许所有域访问
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
        return res.status(204).json({});
    }
    next();
});

app.use(express.static(path.join(__dirname, '/views')));

const api = require('./router/api')

app.use('/', api)

// 获取本机局域网 IPv4 地址（排除回环）
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

const startTime = Date.now();

app.listen(PORT, () => {
  const localURL = `http://localhost:${PORT}`;
  const networkURL = `http://${getLocalIP()}:${PORT}`;
  const elapsed = Date.now() - startTime;

  // 打印彩色启动信息（模仿 Vite 风格）
  console.log();
  console.log(chalk.green(`  Server started in ${chalk.bold(elapsed)}ms`));
  console.log();
  console.log(`  ${chalk.blue('➜')}  Local:   ${chalk.cyan(localURL)}`);
  console.log(`  ${chalk.blue('➜')}  Network: ${chalk.cyan(networkURL)}`);
  console.log();
});