const { Transform } = require('stream');

/**
 * 通用 SSE 事件解析器
 */
function createSseEventParser(onEvent) {
    let currentEvent = null;
    let dataLines = [];

    const reset = () => {
        currentEvent = null;
        dataLines = [];
    };

    const processLine = (line) => {
        const trimmed = line.trim();

        if (trimmed === '') {
            if (currentEvent !== null || dataLines.length > 0) {
                onEvent({
                    event: currentEvent,
                    data: dataLines.join(''),
                });
                reset();
            }
            return;
        }

        if (trimmed.startsWith('event:')) {
            currentEvent = trimmed.slice(6).trim();
            return;
        }

        if (trimmed.startsWith('data:')) {
            dataLines.push(trimmed.slice(5).trimStart());
            return;
        }
    };

    const flush = () => {
        if (currentEvent !== null || dataLines.length > 0) {
            onEvent({
                event: currentEvent,
                data: dataLines.join(''),
            });
            reset();
        }
    };

    return { processLine, flush };
}

// ----------------------------------------------------------------------
// 流式转换器
// ----------------------------------------------------------------------
function createSseTransformer() {
    let buffer = '';
    let pushFn;
    let streamRef = null;        // 修复：使用闭包变量保存 Transform 实例引用
    let fragType = null;          // 'think' | 'response'
    let lastMsgId = null;

    const isContentEvent = (p) => {
        if (!p) return true;
        if (typeof p === 'string' && p.startsWith('response/fragments/')) return true;
        return false;
    };

    const extractMsgIdFromV = (v) => {
        if (v && typeof v === 'object' && v.response && typeof v.response.message_id === 'number') {
            lastMsgId = v.response.message_id;
            // 修复：使用 streamRef 替代 this
            if (streamRef) {
                streamRef.emit('messageId', lastMsgId);
            }
            console.log(`[ID捕获] message_id: ${lastMsgId}`);
        }
    };

    /**
     * 处理片段数组，输出对应内容并更新 fragType
     */
    const processFragments = (frags) => {
        for (const frag of frags) {
            if (!frag) continue;
            if (frag.type === 'THINK') {
                fragType = 'think';
                if (frag.content) {
                    pushFn(formatDelta({ reasoning_content: frag.content }));
                }
            } else if (frag.type === 'RESPONSE') {
                fragType = 'response';
                if (frag.content) {
                    pushFn(formatDelta({ content: frag.content }));
                }
            } else if (frag.type === 'TOOL_SEARCH') {
                // 忽略工具搜索片段（不输出内容）
            }
        }
    };

    /**
     * 递归处理 BATCH 中包含的子操作
     */
    const processBatchItems = (items) => {
        for (const item of items) {
            if (!item) continue;
            const { p, o, v } = item;
            if (p === 'fragments' && o === 'APPEND' && Array.isArray(v)) {
                processFragments(v);
            } else if (p && o && v !== undefined) {
                // 其他可能的子操作（如 has_pending_fragment 等，忽略）
            }
        }
    };

    const handleEvent = (eventObj) => {
        const { event, data } = eventObj;

        if (data === '[DONE]' || event === 'close') {
            pushFn('data: [DONE]\n\n');
            return;
        }

        if (!data) return;

        try {
            const parsed = JSON.parse(data);
            const p = parsed.p;
            const o = parsed.o;
            const v = parsed.v;

            extractMsgIdFromV(v);

            // 1. 初始 fragment 宣告（v.response.fragments）
            if (typeof v === 'object' && v !== null && v.response && Array.isArray(v.response.fragments)) {
                processFragments(v.response.fragments);
                return;
            }

            // 2. BATCH 操作（可能包含 fragments 追加）
            if (p === 'response' && o === 'BATCH' && Array.isArray(v)) {
                processBatchItems(v);
                return;
            }

            // 3. 扁平 fragment 追加（p=response/fragments, o=APPEND）
            if (p === 'response/fragments' && o === 'APPEND' && Array.isArray(v)) {
                processFragments(v);
                return;
            }

            // 4. 纯内容追加（字符串）
            if (typeof v === 'string' && fragType && isContentEvent(p)) {
                if (fragType === 'think') {
                    pushFn(formatDelta({ reasoning_content: v }));
                } else if (fragType === 'response') {
                    pushFn(formatDelta({ content: v }));
                }
            }

            // 5. 其他情况忽略（如状态更新等）
        } catch (err) {
            // 修复：不要静默吞掉错误，至少打印日志以帮助排查
            console.error('[SSE解析错误]', err.message, 'Raw data:', data);
        }
    };

    const formatDelta = (deltaFields) => {
        const delta = {
            choices: [{
                index: 0,
                delta: deltaFields,
                finish_reason: null,
            }],
        };
        return `data: ${JSON.stringify(delta)}\n\n`;
    };

    const { processLine, flush } = createSseEventParser(handleEvent);

    const transformStream = new Transform({
        transform(chunk, encoding, cb) {
            if (!pushFn) pushFn = this.push.bind(this);
            if (!streamRef) streamRef = this; // 绑定实例引用
            buffer += chunk.toString('utf8');
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const line of lines) {
                processLine(line);
            }
            cb();
        },

        flush(cb) {
            if (!pushFn) pushFn = this.push.bind(this);
            if (!streamRef) streamRef = this;
            if (buffer) {
                processLine(buffer);
            }
            flush();
            cb();
        },
    });

    return transformStream;
}

// ----------------------------------------------------------------------
// 非流式聚合器
// ----------------------------------------------------------------------
async function aggregateStream(response) {
    let thinking = '';
    let content = '';
    let finished = false;
    let fragType = null;
    let messageId = null;

    const isContentEvent = (p) => {
        if (!p) return true;
        if (typeof p === 'string' && p.startsWith('response/fragments/')) return true;
        return false;
    };

    const extractMsgIdFromV = (v) => {
        if (v && typeof v === 'object' && v.response && typeof v.response.message_id === 'number') {
            messageId = v.response.message_id;
            console.log(`[聚合ID] message_id: ${messageId}`);
        }
    };

    const processFragments = (frags) => {
        for (const frag of frags) {
            if (!frag) continue;
            if (frag.type === 'THINK') {
                fragType = 'think';
                if (frag.content) thinking += frag.content;
            } else if (frag.type === 'RESPONSE') {
                fragType = 'response';
                if (frag.content) content += frag.content;
            }
        }
    };

    const processBatchItems = (items) => {
        for (const item of items) {
            if (!item) continue;
            const { p, o, v } = item;
            if (p === 'fragments' && o === 'APPEND' && Array.isArray(v)) {
                processFragments(v);
            }
        }
    };

    const handleEvent = ({ event, data }) => {
        if (finished) return;

        if (data === '[DONE]' || event === 'close') {
            finished = true;
            return;
        }

        if (!data) return;

        try {
            const parsed = JSON.parse(data);
            const p = parsed.p;
            const o = parsed.o;
            const v = parsed.v;

            extractMsgIdFromV(v);

            if (typeof v === 'object' && v !== null && v.response && Array.isArray(v.response.fragments)) {
                processFragments(v.response.fragments);
                return;
            }

            if (p === 'response' && o === 'BATCH' && Array.isArray(v)) {
                processBatchItems(v);
                return;
            }

            if (p === 'response/fragments' && o === 'APPEND' && Array.isArray(v)) {
                processFragments(v);
                return;
            }

            if (typeof v === 'string' && fragType && isContentEvent(p)) {
                if (fragType === 'think') {
                    thinking += v;
                } else if (fragType === 'response') {
                    content += v;
                }
            }
        } catch (err) {
            console.error('[聚合SSE解析错误]', err.message, 'Raw data:', data);
        }
    };

    const { processLine, flush } = createSseEventParser(handleEvent);
    let buffer = '';

    for await (const chunk of response.body) {
        buffer += chunk.toString('utf8');
        const lines = buffer.split('\n');
        buffer = lines.pop();

        for (const line of lines) {
            processLine(line);
        }

        if (finished) break;
    }

    if (!finished && buffer) {
        processLine(buffer);
        flush();
    }

    return { thinking, content, messageId };
}

module.exports = { createSseTransformer, aggregateStream };
