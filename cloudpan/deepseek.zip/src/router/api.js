const express = require('express');
const router = express.Router();
const { getPowToken } = require('../util/PowUtil');
const fetch = require('node-fetch');
const md5 = require('md5');
const { createSseTransformer, aggregateStream } = require('../util/stream');

router.use(express.json());
router.use(express.urlencoded({ extended: false }));

const COMMON_HEADERS = {
  accept: '*/*',
  'accept-language': 'zh-CN,zh;q=0.9',
  'authorization': 'Bearer ' + process.env.DS_AUTH_TOKEN,
  'content-type': 'application/json',
  'x-app-version': '2.0.0',
  'x-client-bundle-id': 'com.deepseek.chat',
  'x-client-locale': 'zh_CN',
  'x-client-platform': 'web',
  'x-client-timezone-offset': '28800',
  'x-client-version': '2.0.0',
  'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2007J1SC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.117 Mobile Safari/537.36',
  'Origin': 'https://chat.deepseek.com',
  'Referer': 'https://chat.deepseek.com/',
  'cookie': process.env.DS_COOKIE
};

const SESSION_TTL = parseInt(process.env.SESSION_TTL || '1800000', 10);
const sessionCache = new Map(); // key: chat_session_id（或默认 key）

// 默认会话缓存 key（用于"不指定 session"的旧逻辑）
function getDefaultCacheKey() {
  return 'default::' + md5(process.env.DS_AUTH_TOKEN + process.env.DS_COOKIE);
}

// 创建新会话并缓存
async function createAndCacheSession(cacheKey) {
  const now = Date.now();
  const resp = await fetch('https://chat.deepseek.com/api/v0/chat_session/create', {
    headers: { ...COMMON_HEADERS },
    body: '{}',
    method: 'POST'
  });
  const data = await resp.json();
  const sessionId = data.data.biz_data.chat_session.id;
  const session = { sessionId, parentMessageId: null, createdAt: now };
  sessionCache.set(cacheKey, session);
  console.log('[会话] 新建会话:', sessionId, 'key=', cacheKey);
  return session;
}

// 获取或创建会话
// - 当传入 sessionId 时：若缓存命中且未过期则复用；否则用该 sessionId 建立缓存条目（parentMessageId 通过 history 获取）
// - 当未传入 sessionId 且 forceNew 时：新建
async function getOrCreateSession({ sessionId, forceNew }) {
  const now = Date.now();
  const cacheKey = sessionId || getDefaultCacheKey();

  const cached = sessionCache.get(cacheKey);
  if (!forceNew && cached && (now - cached.createdAt) < SESSION_TTL) {
    return cached;
  }

  if (sessionId) {
    // 切换到已有会话：缓存条目用真实 sessionId，parentMessageId 待从 history 拉取
    const session = { sessionId, parentMessageId: null, createdAt: now };
    sessionCache.set(cacheKey, session);
    return session;
  }

  return await createAndCacheSession(cacheKey);
}

// 拉取某会话的历史，解析出 parentMessageId（最后一条消息的 message_id）
async function fetchHistoryMeta(sessionId) {
  const resp = await fetch(
    'https://chat.deepseek.com/api/v0/chat/history_messages?chat_session_id=' + encodeURIComponent(sessionId),
    { headers: { ...COMMON_HEADERS }, method: 'GET' }
  );
  if (!resp.ok) {
    throw new Error('history_messages HTTP ' + resp.status);
  }
  const data = await resp.json();
  const biz = data.data.biz_data;
  const chatMessages = biz.chat_messages || [];
  const last = chatMessages[chatMessages.length - 1];
  // 优先用 current_message_id，兜底用最后一条 message_id
  const parentMessageId =
    (biz.chat_session && typeof biz.chat_session.current_message_id === 'number')
      ? biz.chat_session.current_message_id
      : (last ? last.message_id : null);
  return parentMessageId;
}

// 用上游真实 message_id 更新 parentMessageId
function updateParentWithRealId(cacheKey, stageId) {
  if (stageId === null || stageId === undefined) return;
  const session = sessionCache.get(cacheKey);
  if (session) {
    session.parentMessageId = stageId;
    console.log(`[会话 ${cacheKey}] parentMessageId 更新为: ${stageId}`);
  }
}

// 发送聊天请求到上游
async function SendChatRequest({ prompt, sessionId, parentMessageId, thinkingEnabled = true, model = 'default', search = false }) {
  const PowToken = await getPowToken();
  const body = {
    chat_session_id: sessionId,
    parent_message_id: parentMessageId,
    model_type: model,
    prompt,
    ref_file_ids: [],
    thinking_enabled: thinkingEnabled,
    search_enabled: search,
    action: null,
    preempt: false
  };
  console.log('[请求] 发送:', { chat_session_id: sessionId, parent_message_id: body.parent_message_id, prompt: prompt.slice(0, 50) });
  const response = await fetch('https://chat.deepseek.com/api/v0/chat/completion', {
    headers: { ...COMMON_HEADERS, 'x-ds-pow-response': PowToken },
    body: JSON.stringify(body),
    method: 'POST'
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Upstream HTTP ${response.status}: ${text}`);
  }
  return response;
}

router.get('/v1/chat_sessions', async (req, res) => {
  try {
    const resp = await fetch(
      'https://chat.deepseek.com/api/v0/chat_session/fetch_page?lte_cursor.pinned=false',
      { headers: { ...COMMON_HEADERS }, method: 'GET' }
    );
    if (!resp.ok) {
      const t = await resp.text();
      return res.status(502).json({ error: { message: 'fetch_page HTTP ' + resp.status + ': ' + t } });
    }
    const data = await resp.json();
    const sessions = (data.data.biz_data.chat_sessions || []).map(s => ({
      id: s.id,
      title: s.title,
      titleType: s.title_type,
      pinned: !!s.pinned,
      modelType: s.model_type,
      updatedAt: s.updated_at
    }));
    return res.json({ sessions, hasMore: !!data.data.biz_data.has_more });
  } catch (e) {
    return res.status(500).json({ error: { message: 'fetch sessions failed: ' + e.message } });
  }
});

router.get('/v1/chat/history', async (req, res) => {
  const sessionId = req.query.chat_session_id;
  if (!sessionId) {
    return res.status(400).json({ error: { message: 'chat_session_id is required' } });
  }
  try {
    const resp = await fetch(
      'https://chat.deepseek.com/api/v0/chat/history_messages?chat_session_id=' + encodeURIComponent(sessionId),
      { headers: { ...COMMON_HEADERS }, method: 'GET' }
    );
    if (!resp.ok) {
      const t = await resp.text();
      return res.status(502).json({ error: { message: 'history_messages HTTP ' + resp.status + ': ' + t } });
    }
    const data = await resp.json();
    const biz = data.data.biz_data;
    const rawMessages = biz.chat_messages || [];

    const messages = rawMessages.map(m => {
      const role = m.role === 'USER' ? 'user' : 'assistant';
      let content = '';
      let reasoning = '';
      for (const f of (m.fragments || [])) {
        if (f.type === 'REQUEST') content = f.content || content;
        else if (f.type === 'RESPONSE') content = f.content || content;
        else if (f.type === 'THINK') reasoning = (reasoning || '') + (f.content || '');
      }
      return { role, content, reasoning, messageId: m.message_id };
    });

    const last = rawMessages[rawMessages.length - 1];
    const parentMessageId =
      (biz.chat_session && typeof biz.chat_session.current_message_id === 'number')
        ? biz.chat_session.current_message_id
        : (last ? last.message_id : null);

    // 同步更新该会话缓存，便于后续 completion 复用
    const cacheKey = sessionId;
    const now = Date.now();
    const existing = sessionCache.get(cacheKey);
    if (existing) {
      existing.parentMessageId = parentMessageId;
      existing.createdAt = now;
    } else {
      sessionCache.set(cacheKey, { sessionId, parentMessageId, createdAt: now });
    }

    return res.json({
      session: {
        id: biz.chat_session.id,
        title: biz.chat_session.title,
        modelType: biz.chat_session.model_type
      },
      messages,
      parentMessageId
    });
  } catch (e) {
    return res.status(500).json({ error: { message: 'fetch history failed: ' + e.message } });
  }
});

router.post('/v1/chat/completion', async (req, res) => {
  const {
    prompt,
    stream = false,
    thinking_enabled = true,
    model = 'default',
    search = false,
    new_session = false,
    chat_session_id = null  // 新增：指定已有会话
  } = req.body || {};

  if (typeof prompt !== 'string' || !prompt.trim()) {
    return res.status(400).json({ error: { message: 'prompt is required', type: 'invalid_request_error' } });
  }

  // 获取或创建会话
  let session;
  let cacheKey;
  try {
    // 指定会话 + 强制新建 互斥：指定会话优先
    const forceNew = !chat_session_id && new_session;
    session = await getOrCreateSession({ sessionId: chat_session_id, forceNew });
    cacheKey = chat_session_id || getDefaultCacheKey();

    // 切换到已有会话且 parentMessageId 未知时，拉取历史补全
    if (chat_session_id && session.parentMessageId === null) {
      try {
        session.parentMessageId = await fetchHistoryMeta(chat_session_id);
        console.log('[会话切换] 从 history 获取 parentMessageId:', session.parentMessageId);
      } catch (e) {
        console.warn('[会话切换] 获取 history 失败，使用 null 继续:', e.message);
        session.parentMessageId = null;
      }
    }
  } catch (e) {
    return res.status(502).json({ error: { message: 'Session create failed: ' + e.message, type: 'upstream_error' } });
  }

  // 请求上游
  let upstream;
  try {
    upstream = await SendChatRequest({
      prompt,
      sessionId: session.sessionId,
      parentMessageId: session.parentMessageId,
      thinkingEnabled: thinking_enabled,
      model,
      search
    });
  } catch (e) {
    return res.status(502).json({ error: { message: 'Upstream error: ' + e.message, type: 'upstream_error' } });
  }

  // ---- 非流式 ----
  if (!stream) {
    try {
      const { thinking, content, messageId } = await aggregateStream(upstream);
      updateParentWithRealId(cacheKey, messageId);
      return res.json({
        chat_session_id: session.sessionId,
        choices: [{
          index: 0,
          message: { role: 'assistant', content, reasoning_content: thinking || null },
          finish_reason: 'stop'
        }]
      });
    } catch (e) {
      return res.status(500).json({ error: { message: 'Aggregate failed: ' + e.message } });
    }
  }

  // ---- 流式 ----
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  
  res.write(`data: ${JSON.stringify({ chat_session_id: session.sessionId })}\n\n`); 

  const transformer = createSseTransformer();
  let lastStageId = null;
  let streamEnded = false;

  const timeout = setTimeout(() => {
    if (!streamEnded) {
      streamEnded = true;
      res.write(`data: ${JSON.stringify({ error: { message: 'upstream timeout' } })}\n\n`);
      res.end();
      destroyStreams();
    }
  }, 30000);

  function destroyStreams() {
    if (upstream.body && upstream.body.destroy) upstream.body.destroy();
    if (transformer.destroy) transformer.destroy();
  }

  const onClose = () => { clearTimeout(timeout); destroyStreams(); res.end(); };
  req.on('close', onClose);

  transformer.on('error', (e) => {
    clearTimeout(timeout); streamEnded = true;
    res.write(`data: ${JSON.stringify({ error: { message: e.message } })}\n\n`);
    res.end(); destroyStreams();
  });

  upstream.body.on('error', (err) => {
    clearTimeout(timeout); streamEnded = true;
    res.write(`data: ${JSON.stringify({ error: { message: 'upstream stream error: ' + err.message } })}\n\n`);
    res.end(); destroyStreams();
  });

  transformer.on('messageId', (stageId) => { lastStageId = stageId; });

  upstream.body.on('data', () => { clearTimeout(timeout); timeout.refresh(); });

  upstream.body.pipe(transformer).pipe(res);

  upstream.body.on('end', () => {
    clearTimeout(timeout);
    req.off('close', onClose);
    if (lastStageId) updateParentWithRealId(cacheKey, lastStageId);
    console.log('[流] 上游流正常结束');
  });
});

router.post('/v1/chat_session/delete', async (req, res) => {
  const { chat_session_id } = req.body || {};

  if (!chat_session_id) {
    return res.status(400).json({ error: { message: 'chat_session_id is required' } });
  }

  try {
    // 请求 DeepSeek 上游删除接口
    const resp = await fetch('https://chat.deepseek.com/api/v0/chat_session/delete', {
      method: 'POST',
      headers: { 
        ...COMMON_HEADERS, // 复用你定义的通用请求头
        'content-type': 'application/json' 
      },
      body: JSON.stringify({ chat_session_id })
    });

    if (!resp.ok) {
      const text = await resp.text();
      return res.status(502).json({ 
        error: { 
          message: 'Upstream delete failed HTTP ' + resp.status + ': ' + text,
          type: 'upstream_error' 
        } 
      });
    }

    const data = await resp.json();

    // 检查上游业务状态码
    if (data.code !== 0 || data.data?.biz_code !== 0) {
      return res.status(500).json({ 
        error: { 
          message: 'Delete session biz error: ' + (data.data?.biz_msg || data.msg || 'Unknown'),
          type: 'upstream_biz_error'
        } 
      });
    }

    sessionCache.delete(chat_session_id);
    
    // 成功返回给前端
    return res.json({ success: true, message: 'Session deleted successfully' });

  } catch (error) {
    console.error('[删除会话] 发生异常:', error);
    return res.status(500).json({ 
      error: { 
        message: 'Internal server error: ' + error.message,
        type: 'internal_error' 
      } 
    });
  }
});

module.exports = router;
